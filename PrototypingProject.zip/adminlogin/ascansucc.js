setTimeout(function () {
    window.location.href = "../adminlogin/adminpage2.html"; 
  }, 3500);