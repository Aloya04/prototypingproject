setTimeout(function () {
    window.location.href = "../UnableToScan/unabletoscan.html"; 
  }, 3500);