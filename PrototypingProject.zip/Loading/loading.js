setTimeout(function () {
    window.location.href = "../Homepage/homepage.html"; 
  }, 3500);