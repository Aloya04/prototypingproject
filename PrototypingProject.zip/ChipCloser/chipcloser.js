setTimeout(function () {
    window.location.href = "../adminlogin/admin-scansuccess.html"; 
  }, 3500);