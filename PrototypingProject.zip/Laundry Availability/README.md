# Boilerplate: HTML5, CSS and JavaScript

Here's a quick start for any project.

## Usage

* Copy the folder named `boilerplate` in your Filemagager
* Paste the folder somewhere suitable.
* Rename the folder to something usefull.

That's it!
